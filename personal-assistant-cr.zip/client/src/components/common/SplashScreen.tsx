import { FC } from 'react';

const SplashScreen: FC = () => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-primary">
      <div className="text-center">
        <div className="mb-4 flex justify-center">
          <div className="h-24 w-24 rounded-full object-cover border-4 border-white shadow-lg bg-cover bg-center" 
               style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1496372412473-e8548ffd82bc?auto=format&fit=crop&w=150&q=80)' }} />
        </div>
        <h1 className="font-poppins text-3xl font-bold text-white mb-2">My Personal Assistant</h1>
        <p className="text-white text-lg">Costa Rica</p>
      </div>
    </div>
  );
};

export default SplashScreen;
