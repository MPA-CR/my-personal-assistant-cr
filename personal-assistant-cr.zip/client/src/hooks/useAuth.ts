import { createContext, useContext, useState, useEffect, ReactNode, createElement } from 'react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { UserWithoutPassword } from '@/lib/types';

interface AuthContextType {
  user: UserWithoutPassword | null;
  login: (username: string, password: string) => Promise<void>;
  register: (userData: any) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (data: any) => Promise<void>;
  isLoading: boolean;
  isUpdating: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserWithoutPassword | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  
  // Check if user is already logged in
  useEffect(() => {
    const fetchCurrentUser = async () => {
      setIsLoading(true);
      try {
        const response = await fetch('/api/auth/me', {
          credentials: 'include'
        });
        
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
        } else {
          // Clear user data if not authenticated
          setUser(null);
        }
      } catch (error) {
        console.error('Failed to fetch current user:', error);
        // Clear user data on error
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchCurrentUser();
  }, []);
  
  const login = async (username: string, password: string) => {
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/auth/login', { username, password });
      const userData = await response.json();
      setUser(userData);
    } finally {
      setIsLoading(false);
    }
  };
  
  const register = async (userData: any) => {
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/auth/register', userData);
      const newUser = await response.json();
      
      // After registration, log the user in
      await login(userData.username, userData.password);
    } finally {
      setIsLoading(false);
    }
  };
  
  const logout = async () => {
    try {
      await apiRequest('GET', '/api/auth/logout', undefined);
      setUser(null);
      queryClient.clear();
    } catch (error) {
      console.error('Failed to logout:', error);
      throw error;
    }
  };
  
  const updateProfile = async (data: any) => {
    if (!user) throw new Error('Not authenticated');
    
    setIsUpdating(true);
    try {
      const response = await apiRequest('PATCH', `/api/users/${user.id}`, data);
      const updatedUser = await response.json();
      setUser(updatedUser);
      return updatedUser;
    } finally {
      setIsUpdating(false);
    }
  };
  
  const value = {
    user,
    login,
    register,
    logout,
    updateProfile,
    isLoading,
    isUpdating
  };
  
  return createElement(AuthContext.Provider, { value }, children);
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
