import { FC, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ServiceCategory, InsertServiceCategory } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Skeleton } from '@/components/ui/skeleton';

const ServiceManagement: FC = () => {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory | null>(null);
  const { toast } = useToast();
  
  const { data: categories, isLoading } = useQuery<ServiceCategory[]>({
    queryKey: ['/api/service-categories'],
  });

  const categorySchema = z.object({
    name: z.string().min(2, "Name must be at least 2 characters"),
    icon: z.string().min(2, "Icon is required"),
    description: z.string().optional(),
  });

  const addForm = useForm<z.infer<typeof categorySchema>>({
    resolver: zodResolver(categorySchema),
    defaultValues: {
      name: "",
      icon: "ri-service-line",
      description: "",
    },
  });

  const editForm = useForm<z.infer<typeof categorySchema>>({
    resolver: zodResolver(categorySchema),
    defaultValues: {
      name: "",
      icon: "",
      description: "",
    },
  });

  const handleAddCategory = async (data: z.infer<typeof categorySchema>) => {
    try {
      const categoryData: InsertServiceCategory = {
        name: data.name,
        icon: data.icon,
        description: data.description || "",
      };
      
      await apiRequest('POST', '/api/service-categories', categoryData);
      
      toast({
        title: "Success",
        description: "Service category added successfully",
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/service-categories'] });
      setIsAddDialogOpen(false);
      addForm.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  };

  const handleEditCategory = async (data: z.infer<typeof categorySchema>) => {
    if (!selectedCategory) return;
    
    try {
      await apiRequest('PATCH', `/api/service-categories/${selectedCategory.id}`, data);
      
      toast({
        title: "Success",
        description: "Service category updated successfully",
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/service-categories'] });
      setIsEditDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  };

  const handleDeleteCategory = async (id: number) => {
    if (!confirm("Are you sure you want to delete this category?")) return;
    
    try {
      await apiRequest('DELETE', `/api/service-categories/${id}`, undefined);
      
      toast({
        title: "Success",
        description: "Service category deleted successfully",
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/service-categories'] });
    } catch (error) {
      toast({
        title: "Error",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  };

  const openEditDialog = (category: ServiceCategory) => {
    setSelectedCategory(category);
    editForm.reset({
      name: category.name,
      icon: category.icon,
      description: category.description || "",
    });
    setIsEditDialogOpen(true);
  };

  const iconOptions = [
    { value: "ri-translate-2-line", label: "Translator" },
    { value: "ri-shield-check-line", label: "Security" },
    { value: "ri-route-line", label: "Tour Guide" },
    { value: "ri-car-line", label: "Driver" },
    { value: "ri-restaurant-line", label: "Chef" },
    { value: "ri-heart-line", label: "Childcare" },
    { value: "ri-service-line", label: "General Service" },
    { value: "ri-user-line", label: "Assistant" },
    { value: "ri-home-line", label: "Accommodation" },
    { value: "ri-shopping-bag-line", label: "Shopping" },
  ];

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Service Categories</CardTitle>
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <i className="ri-add-line mr-2"></i>
            Add Category
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex items-center space-x-4">
                  <Skeleton className="h-12 w-full" />
                </div>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Icon</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories?.map((category) => (
                  <TableRow key={category.id}>
                    <TableCell>{category.id}</TableCell>
                    <TableCell>
                      <i className={`${category.icon} text-xl text-primary`}></i>
                    </TableCell>
                    <TableCell>{category.name}</TableCell>
                    <TableCell>{category.description || '-'}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => openEditDialog(category)}
                        >
                          <i className="ri-edit-line mr-1"></i>
                          Edit
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm" 
                          onClick={() => handleDeleteCategory(category.id)}
                        >
                          <i className="ri-delete-bin-line mr-1"></i>
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                
                {(!categories || categories.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center">
                      No service categories found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Add Category Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Service Category</DialogTitle>
            <DialogDescription>
              Create a new service category
            </DialogDescription>
          </DialogHeader>
          
          <Form {...addForm}>
            <form onSubmit={addForm.handleSubmit(handleAddCategory)} className="space-y-4">
              <FormField
                control={addForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Category Name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={addForm.control}
                name="icon"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Icon (RemixIcon class)</FormLabel>
                    <div className="grid grid-cols-5 gap-2 mb-2">
                      {iconOptions.map((icon) => (
                        <div
                          key={icon.value}
                          className={`flex flex-col items-center p-2 rounded-md cursor-pointer border ${
                            field.value === icon.value ? 'border-primary bg-primary/10' : 'border-gray-200'
                          }`}
                          onClick={() => addForm.setValue('icon', icon.value)}
                        >
                          <i className={`${icon.value} text-xl ${field.value === icon.value ? 'text-primary' : ''}`}></i>
                          <span className="text-xs mt-1 truncate w-full text-center">{icon.label}</span>
                        </div>
                      ))}
                    </div>
                    <FormControl>
                      <Input placeholder="ri-icon-name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={addForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Category description" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Add Category</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Category Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Service Category</DialogTitle>
            <DialogDescription>
              Update service category information
            </DialogDescription>
          </DialogHeader>
          
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(handleEditCategory)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Category Name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={editForm.control}
                name="icon"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Icon (RemixIcon class)</FormLabel>
                    <div className="grid grid-cols-5 gap-2 mb-2">
                      {iconOptions.map((icon) => (
                        <div
                          key={icon.value}
                          className={`flex flex-col items-center p-2 rounded-md cursor-pointer border ${
                            field.value === icon.value ? 'border-primary bg-primary/10' : 'border-gray-200'
                          }`}
                          onClick={() => editForm.setValue('icon', icon.value)}
                        >
                          <i className={`${icon.value} text-xl ${field.value === icon.value ? 'text-primary' : ''}`}></i>
                          <span className="text-xs mt-1 truncate w-full text-center">{icon.label}</span>
                        </div>
                      ))}
                    </div>
                    <FormControl>
                      <Input placeholder="ri-icon-name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={editForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Category description" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit">Update Category</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ServiceManagement;
