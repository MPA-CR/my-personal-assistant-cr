import { FC } from 'react';
import AdminPanel from '@/components/admin/AdminPanel';
import ServiceManagement from '@/components/admin/ServiceManagement';

const AdminServices: FC = () => {
  return (
    <AdminPanel title="Services Management">
      <ServiceManagement />
    </AdminPanel>
  );
};

export default AdminServices;
