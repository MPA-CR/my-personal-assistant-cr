import { FC } from 'react';
import AdminPanel from '@/components/admin/AdminPanel';
import BookingManagement from '@/components/admin/BookingManagement';

const AdminBookings: FC = () => {
  return (
    <AdminPanel title="Bookings Management">
      <BookingManagement />
    </AdminPanel>
  );
};

export default AdminBookings;
