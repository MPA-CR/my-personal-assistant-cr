import { FC } from 'react';
import AdminPanel from '@/components/admin/AdminPanel';
import AssistantManagement from '@/components/admin/AssistantManagement';

const AdminAssistants: FC = () => {
  return (
    <AdminPanel title="Assistants Management">
      <AssistantManagement />
    </AdminPanel>
  );
};

export default AdminAssistants;
