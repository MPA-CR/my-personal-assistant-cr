import { User, ServiceCategory, Service, Booking, Review, Message, Location } from "@shared/schema";

export interface UserWithoutPassword extends Omit<User, 'password'> {}

export interface ServiceWithCategoryName extends Service {
  categoryName: string;
}

export interface BookingWithDetails extends Booking {
  assistantName: string;
  clientName: string;
  serviceName: string;
}

export interface ReviewWithDetails extends Review {
  clientName: string;
}

export interface AssistantWithServices extends UserWithoutPassword {
  services: ServiceWithCategoryName[];
}

export interface ConversationPreview {
  userId: number;
  userName: string;
  userImage: string | null;
  lastMessage: string;
  lastMessageTime: Date;
  unread: number;
}

export interface MapMarker {
  id: number;
  position: [number, number];
  type: string;
  user: UserWithoutPassword;
}
