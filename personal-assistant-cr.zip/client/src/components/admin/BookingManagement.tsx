import { FC, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Booking } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { format } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';

const BookingManagement: FC = () => {
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [newStatus, setNewStatus] = useState<string>('');
  const { toast } = useToast();
  
  const { data: bookings, isLoading } = useQuery<Booking[]>({
    queryKey: ['/api/bookings'],
  });

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'pending':
        return 'outline';
      case 'confirmed':
        return 'secondary';
      case 'completed':
        return 'default';
      case 'cancelled':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const handleStatusChange = async () => {
    if (!selectedBooking || !newStatus) return;
    
    try {
      await apiRequest('PATCH', `/api/bookings/${selectedBooking.id}`, {
        status: newStatus
      });
      
      toast({
        title: "Status Updated",
        description: `Booking status changed to ${newStatus}`,
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      setIsDetailsDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  };

  const openDetailsDialog = (booking: Booking) => {
    setSelectedBooking(booking);
    setNewStatus(booking.status);
    setIsDetailsDialogOpen(true);
  };

  const formatDateTime = (date: Date) => {
    return format(new Date(date), 'MMM d, yyyy h:mm a');
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Bookings Management</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex items-center space-x-4">
                  <Skeleton className="h-12 w-full" />
                </div>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Assistant</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bookings?.map((booking) => (
                  <TableRow key={booking.id}>
                    <TableCell>#{booking.id}</TableCell>
                    <TableCell>{booking.clientId}</TableCell>
                    <TableCell>{booking.assistantId}</TableCell>
                    <TableCell>{formatDateTime(booking.startTime)}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadgeVariant(booking.status)}>
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell>${booking.totalAmount.toFixed(2)}</TableCell>
                    <TableCell>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => openDetailsDialog(booking)}
                      >
                        <i className="ri-eye-line mr-1"></i>
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                
                {(!bookings || bookings.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">
                      No bookings found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Booking Details Dialog */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Booking Details</DialogTitle>
            <DialogDescription>
              View and update booking information
            </DialogDescription>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">Booking ID</p>
                  <p>#{selectedBooking.id}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Status</p>
                  <Badge variant={getStatusBadgeVariant(selectedBooking.status)}>
                    {selectedBooking.status.charAt(0).toUpperCase() + selectedBooking.status.slice(1)}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Client ID</p>
                  <p>{selectedBooking.clientId}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Assistant ID</p>
                  <p>{selectedBooking.assistantId}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Start Time</p>
                  <p>{formatDateTime(selectedBooking.startTime)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">End Time</p>
                  <p>{formatDateTime(selectedBooking.endTime)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Service ID</p>
                  <p>{selectedBooking.serviceId}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Amount</p>
                  <p className="font-semibold">${selectedBooking.totalAmount.toFixed(2)}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Location</p>
                <p>{selectedBooking.location.address || 'No address provided'}</p>
                <p className="text-xs text-gray-400">
                  Lat: {selectedBooking.location.lat}, Lng: {selectedBooking.location.lng}
                </p>
              </div>
              
              {selectedBooking.notes && (
                <div>
                  <p className="text-sm font-medium text-gray-500">Notes</p>
                  <p>{selectedBooking.notes}</p>
                </div>
              )}
              
              <div className="pt-3 border-t">
                <p className="text-sm font-medium mb-2">Update Status</p>
                <Select
                  value={newStatus}
                  onValueChange={setNewStatus}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="confirmed">Confirmed</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDetailsDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleStatusChange}
                  disabled={newStatus === selectedBooking.status}
                >
                  Update Status
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default BookingManagement;
