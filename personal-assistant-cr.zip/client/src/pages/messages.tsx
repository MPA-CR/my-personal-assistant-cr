import { FC, useState, useEffect } from 'react';
import AppLayout from '@/components/layout/AppLayout';
import { useAuth } from '@/hooks/useAuth';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useQuery } from '@tanstack/react-query';
import { ConversationPreview } from '@/lib/types';
import { Message } from '@shared/schema';
import { format } from 'date-fns';
import { Textarea } from '@/components/ui/textarea';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';

const Messages: FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedUser, setSelectedUser] = useState<ConversationPreview | null>(null);
  const [messageText, setMessageText] = useState('');
  const [isSending, setIsSending] = useState(false);
  
  // Get list of conversations
  const { data: allMessages, isLoading: isLoadingConversations } = useQuery<Message[]>({
    queryKey: ['/api/messages'],
    enabled: !!user,
  });
  
  // Get messages for selected conversation
  const { data: conversationMessages, isLoading: isLoadingMessages } = useQuery<Message[]>({
    queryKey: ['/api/messages', user?.id, selectedUser?.userId],
    enabled: !!user && !!selectedUser,
  });
  
  // Process all messages to get conversation previews
  const [conversations, setConversations] = useState<ConversationPreview[]>([]);
  
  useEffect(() => {
    if (!allMessages || !user) return;
    
    const convoMap = new Map<number, ConversationPreview>();
    
    allMessages.forEach(message => {
      const otherUserId = message.senderId === user.id ? message.receiverId : message.senderId;
      
      if (!convoMap.has(otherUserId)) {
        convoMap.set(otherUserId, {
          userId: otherUserId,
          userName: `User #${otherUserId}`,
          userImage: null,
          lastMessage: message.content,
          lastMessageTime: message.createdAt,
          unread: message.receiverId === user.id && !message.isRead ? 1 : 0
        });
      } else {
        const existing = convoMap.get(otherUserId)!;
        const messageTime = new Date(message.createdAt);
        const existingTime = new Date(existing.lastMessageTime);
        
        if (messageTime > existingTime) {
          existing.lastMessage = message.content;
          existing.lastMessageTime = message.createdAt;
        }
        
        if (message.receiverId === user.id && !message.isRead) {
          existing.unread += 1;
        }
        
        convoMap.set(otherUserId, existing);
      }
    });
    
    // Sort by most recent message
    const sortedConversations = Array.from(convoMap.values()).sort((a, b) => {
      return new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime();
    });
    
    setConversations(sortedConversations);
  }, [allMessages, user]);
  
  const handleSendMessage = async () => {
    if (!user || !selectedUser || !messageText.trim()) return;
    
    try {
      setIsSending(true);
      
      await apiRequest('POST', '/api/messages', {
        senderId: user.id,
        receiverId: selectedUser.userId,
        content: messageText,
        isRead: false
      });
      
      setMessageText('');
      queryClient.invalidateQueries({ queryKey: ['/api/messages'] });
      queryClient.invalidateQueries({ queryKey: ['/api/messages', user.id, selectedUser.userId] });
    } catch (error) {
      toast({
        title: "Error",
        description: (error as Error).message,
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };
  
  const formatMessageTime = (date: Date) => {
    const messageDate = new Date(date);
    const today = new Date();
    
    if (messageDate.toDateString() === today.toDateString()) {
      return format(messageDate, 'h:mm a');
    } else {
      return format(messageDate, 'MMM d');
    }
  };
  
  if (!user) {
    return (
      <AppLayout>
        <div className="p-6 flex flex-col items-center justify-center min-h-[70vh]">
          <i className="ri-message-3-line text-5xl text-gray-300 mb-4"></i>
          <h3 className="text-xl font-semibold mb-2">Sign in to view messages</h3>
          <p className="text-gray-500 mb-6 text-center">
            You need to be signed in to view and send messages
          </p>
          <Button asChild>
            <Link href="/login">Sign In</Link>
          </Button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="flex flex-col h-full">
        {selectedUser ? (
          <div className="flex flex-col h-full">
            <div className="border-b p-4 flex items-center">
              <button 
                className="mr-3 md:hidden" 
                onClick={() => setSelectedUser(null)}
              >
                <i className="ri-arrow-left-line text-xl"></i>
              </button>
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center mr-3">
                  {selectedUser.userImage ? (
                    <div 
                      className="h-full w-full bg-cover bg-center rounded-full" 
                      style={{ backgroundImage: `url(${selectedUser.userImage})` }}
                    />
                  ) : (
                    <i className="ri-user-line text-gray-600"></i>
                  )}
                </div>
                <div>
                  <h3 className="font-semibold">{selectedUser.userName}</h3>
                </div>
              </div>
            </div>
            
            <div className="flex-1 p-4 overflow-y-auto space-y-4 pb-16">
              {isLoadingMessages ? (
                Array(5).fill(0).map((_, i) => (
                  <div key={i} className={`flex ${i % 2 === 0 ? 'justify-start' : 'justify-end'}`}>
                    <Skeleton className={`h-10 w-40 rounded-lg ${i % 2 === 0 ? 'rounded-tl-none' : 'rounded-tr-none'}`} />
                  </div>
                ))
              ) : conversationMessages && conversationMessages.length > 0 ? (
                conversationMessages.map(message => (
                  <div 
                    key={message.id} 
                    className={`flex ${message.senderId === user.id ? 'justify-end' : 'justify-start'}`}
                  >
                    <div 
                      className={`max-w-[80%] p-3 rounded-lg ${
                        message.senderId === user.id 
                          ? 'bg-primary text-white rounded-tr-none' 
                          : 'bg-gray-200 text-gray-800 rounded-tl-none'
                      }`}
                    >
                      <p>{message.content}</p>
                      <p className={`text-xs mt-1 ${
                        message.senderId === user.id ? 'text-primary-foreground/70' : 'text-gray-500'
                      }`}>
                        {formatMessageTime(message.createdAt)}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12">
                  <i className="ri-chat-1-line text-5xl text-gray-300 mb-4"></i>
                  <p className="text-gray-500">No messages yet. Start the conversation!</p>
                </div>
              )}
            </div>
            
            <div className="border-t p-4 fixed bottom-16 left-0 right-0 bg-white md:bottom-0">
              <div className="flex space-x-2">
                <Textarea
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder="Type a message..."
                  className="min-h-[44px] max-h-[120px]"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                />
                <Button 
                  onClick={handleSendMessage}
                  disabled={!messageText.trim() || isSending}
                >
                  Send
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col h-full">
            <div className="border-b p-4">
              <h1 className="font-poppins text-2xl font-semibold">Messages</h1>
              <div className="mt-3">
                <Input placeholder="Search messages..." />
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              {isLoadingConversations ? (
                Array(5).fill(0).map((_, i) => (
                  <div key={i} className="border-b p-4 flex items-center">
                    <Skeleton className="h-12 w-12 rounded-full mr-3" />
                    <div className="flex-1">
                      <Skeleton className="h-5 w-32 mb-1" />
                      <Skeleton className="h-4 w-48" />
                    </div>
                    <Skeleton className="h-5 w-10" />
                  </div>
                ))
              ) : conversations.length > 0 ? (
                conversations.map(conversation => (
                  <button
                    key={conversation.userId}
                    className="w-full text-left border-b hover:bg-gray-50 transition-colors duration-150"
                    onClick={() => setSelectedUser(conversation)}
                  >
                    <div className="p-4 flex items-center">
                      <div className="relative">
                        <div className="h-12 w-12 rounded-full bg-gray-300 flex items-center justify-center mr-3">
                          {conversation.userImage ? (
                            <div 
                              className="h-full w-full bg-cover bg-center rounded-full" 
                              style={{ backgroundImage: `url(${conversation.userImage})` }}
                            />
                          ) : (
                            <i className="ri-user-line text-gray-600 text-xl"></i>
                          )}
                        </div>
                        {conversation.unread > 0 && (
                          <div className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                            {conversation.unread}
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <h3 className="font-semibold">{conversation.userName}</h3>
                          <span className="text-xs text-gray-500">
                            {formatMessageTime(conversation.lastMessageTime)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 truncate">
                          {conversation.lastMessage}
                        </p>
                      </div>
                    </div>
                  </button>
                ))
              ) : (
                <div className="text-center py-12">
                  <i className="ri-chat-3-line text-5xl text-gray-300 mb-4"></i>
                  <h3 className="text-lg font-medium mb-2">No messages yet</h3>
                  <p className="text-gray-500 mb-6">You don't have any conversations</p>
                  <Button asChild>
                    <Link href="/">Find an Assistant</Link>
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Messages;
