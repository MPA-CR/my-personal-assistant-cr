import { useState, useEffect } from 'react';
import { Location } from '@shared/schema';

export const useLocation = () => {
  // Initialize with a default location (San Jose, Costa Rica)
  const [currentLocation, setCurrentLocation] = useState<Location>({
    lat: 9.9281,
    lng: -84.0907
  });
  
  const [isLoadingLocation, setIsLoadingLocation] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const getLocation = () => {
      // Set initial default location first
      setCurrentLocation({
        lat: 9.9281,
        lng: -84.0907
      });
      
      // Then try to get actual location
      if (navigator.geolocation) {
        try {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              setCurrentLocation({
                lat: position.coords.latitude,
                lng: position.coords.longitude
              });
              setIsLoadingLocation(false);
              setError(null);
            },
            (err) => {
              console.error("Error getting location:", err);
              setError("Failed to get your location. Using default location in Costa Rica.");
              setIsLoadingLocation(false);
            },
            { 
              enableHighAccuracy: false,
              timeout: 10000,
              maximumAge: 60000
            }
          );
        } catch (e) {
          console.error("Exception getting location:", e);
          setError("Failed to access location services. Using default location in Costa Rica.");
          setIsLoadingLocation(false);
        }
      } else {
        setError("Geolocation is not supported by this browser. Using default location in Costa Rica.");
        setIsLoadingLocation(false);
      }
    };
    
    getLocation();
  }, []);
  
  const refreshLocation = () => {
    setIsLoadingLocation(true);
    if (navigator.geolocation) {
      try {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setCurrentLocation({
              lat: position.coords.latitude,
              lng: position.coords.longitude
            });
            setIsLoadingLocation(false);
            setError(null);
          },
          (err) => {
            console.error("Error refreshing location:", err);
            setError("Failed to refresh your location. Using previous location.");
            setIsLoadingLocation(false);
          },
          { 
            enableHighAccuracy: false,
            timeout: 10000,
            maximumAge: 60000
          }
        );
      } catch (e) {
        console.error("Exception refreshing location:", e);
        setError("Failed to access location services. Using previous location.");
        setIsLoadingLocation(false);
      }
    }
  };
  
  return {
    currentLocation,
    isLoadingLocation,
    error,
    refreshLocation
  };
};
