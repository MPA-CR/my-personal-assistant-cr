import { FC, ReactNode, useState } from 'react';
import Header from '@/components/common/Header';
import BottomNavigation from '@/components/layout/BottomNavigation';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useAuth } from '@/hooks/useAuth';
import { Link, useLocation } from 'wouter';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';

interface AppLayoutProps {
  children: ReactNode;
  showBottomNav?: boolean;
}

const AppLayout: FC<AppLayoutProps> = ({ children, showBottomNav = true }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  const [location] = useLocation();

  const handleMenuClick = () => {
    setIsMenuOpen(true);
  };

  const handleLogout = async () => {
    await logout();
    setIsMenuOpen(false);
  };

  return (
    <div className="app-container h-screen flex flex-col relative">
      <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
        <SheetContent side="left" className="w-[85%] sm:w-[350px]">
          <div className="flex flex-col h-full">
            <div className="pt-8 pb-4">
              <div className="flex items-center space-x-4 px-4">
                <div className="h-12 w-12 rounded-full bg-gray-300 flex items-center justify-center overflow-hidden">
                  {user?.profileImage ? (
                    <div 
                      className="h-full w-full bg-cover bg-center" 
                      style={{ backgroundImage: `url(${user.profileImage})` }}
                    />
                  ) : (
                    <i className="ri-user-line text-2xl text-gray-600"></i>
                  )}
                </div>
                <div>
                  {user ? (
                    <div>
                      <h2 className="text-lg font-semibold">{user.fullName}</h2>
                      <p className="text-sm text-gray-500">{user.email}</p>
                    </div>
                  ) : (
                    <div>
                      <Link href="/login">
                        <p className="text-primary cursor-pointer font-medium">Sign in</p>
                      </Link>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <Separator />
            
            <nav className="py-4 flex-1">
              <div className="space-y-1 px-2">
                <Link 
                  href="/" 
                  className={`flex items-center px-3 py-2 rounded-md ${location === '/' ? 'bg-primary/10 text-primary' : 'text-gray-700 hover:bg-gray-100'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                    <polyline points="9 22 9 12 15 12 15 22"/>
                  </svg>
                  <span>Home</span>
                </Link>
                
                <Link 
                  href="/bookings" 
                  className={`flex items-center px-3 py-2 rounded-md ${location === '/bookings' ? 'bg-primary/10 text-primary' : 'text-gray-700 hover:bg-gray-100'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect width="18" height="18" x="3" y="4" rx="2" ry="2"/>
                    <line x1="16" x2="16" y1="2" y2="6"/>
                    <line x1="8" x2="8" y1="2" y2="6"/>
                    <line x1="3" x2="21" y1="10" y2="10"/>
                  </svg>
                  <span>My Bookings</span>
                </Link>
                
                <Link 
                  href="/messages" 
                  className={`flex items-center px-3 py-2 rounded-md ${location === '/messages' ? 'bg-primary/10 text-primary' : 'text-gray-700 hover:bg-gray-100'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                  </svg>
                  <span>Messages</span>
                </Link>
                
                <Link 
                  href="/profile" 
                  className={`flex items-center px-3 py-2 rounded-md ${location === '/profile' ? 'bg-primary/10 text-primary' : 'text-gray-700 hover:bg-gray-100'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                  </svg>
                  <span>Profile</span>
                </Link>
                
                {user?.role === 'admin' && (
                  <Link 
                    href="/admin" 
                    className={`flex items-center px-3 py-2 rounded-md ${location.startsWith('/admin') ? 'bg-primary/10 text-primary' : 'text-gray-700 hover:bg-gray-100'}`}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="mr-3 h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect width="18" height="18" x="3" y="3" rx="2" ry="2"/>
                      <line x1="3" x2="21" y1="9" y2="9"/>
                      <path d="M9 21v-6a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v6"/>
                    </svg>
                    <span>Admin Dashboard</span>
                  </Link>
                )}
              </div>
            </nav>
            
            <Separator />
            
            <div className="p-4">
              {user ? (
                <Button variant="outline" className="w-full" onClick={handleLogout}>
                  <i className="ri-logout-box-line mr-2"></i>
                  Sign out
                </Button>
              ) : (
                <Link href="/login">
                  <Button className="w-full" onClick={() => setIsMenuOpen(false)}>
                    Sign in
                  </Button>
                </Link>
              )}
            </div>
            
            <div className="p-4 text-sm text-gray-500">
              <p>My Personal Assistant, CR</p>
              <p className="text-xs mt-1">© 2023 All rights reserved</p>
              <p className="mt-2 text-xs">
                <i className="ri-heart-line text-secondary mr-1"></i>
                LGBT Friendly Service
              </p>
            </div>
          </div>
        </SheetContent>
      </Sheet>
      
      <Header onMenuClick={handleMenuClick} />
      
      <main className="flex-1 overflow-hidden">
        {children}
      </main>
      
      {showBottomNav && <BottomNavigation />}
    </div>
  );
};

export default AppLayout;
