import { FC } from 'react';
import { AssistantWithServices } from '@/lib/types';
import { ServiceCategory } from '@shared/schema';

interface AssistantCardProps {
  assistant: AssistantWithServices;
  categories: ServiceCategory[];
  distance?: number;
  onClick: () => void;
}

const AssistantCard: FC<AssistantCardProps> = ({ 
  assistant, 
  categories,
  distance, 
  onClick 
}) => {
  const primaryService = assistant.services[0];
  
  // Get the price range of services
  const minPrice = Math.min(...assistant.services.map(s => s.pricePerHour));
  const maxPrice = Math.max(...assistant.services.map(s => s.pricePerHour));
  
  // Get category names for display
  const serviceCategories = assistant.services.map(service => {
    const category = categories.find(c => c.id === service.categoryId);
    return {
      id: service.categoryId,
      name: category?.name || 'Unknown',
      isPrimary: service.id === primaryService?.id
    };
  });

  return (
    <div 
      className="assistant-card bg-white rounded-xl shadow-sm p-3 border border-gray-light/50 cursor-pointer"
      onClick={onClick}
    >
      <div className="flex items-start">
        <div 
          className="w-16 h-16 rounded-lg bg-gray-200 mr-3 bg-cover bg-center"
          style={{ 
            backgroundImage: assistant.profileImage 
              ? `url(${assistant.profileImage})` 
              : 'none'
          }}
        >
          {!assistant.profileImage && (
            <div className="w-full h-full flex items-center justify-center">
              <i className="ri-user-line text-gray-400 text-2xl"></i>
            </div>
          )}
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-semibold">{assistant.fullName}</h3>
              <div className="flex items-center text-sm text-gray mb-1">
                <i className="ri-map-pin-line mr-1 text-xs"></i>
                <span>
                  {distance
                    ? `${distance < 1 
                        ? `${Math.round(distance * 1000)} m` 
                        : `${distance.toFixed(1)} km`}`
                    : 'Costa Rica'}
                </span>
              </div>
            </div>
            <div className="flex items-center">
              <i className="ri-star-fill text-accent text-sm"></i>
              <span className="ml-1 font-medium">
                {assistant.avgRating 
                  ? assistant.avgRating.toFixed(1) 
                  : 'New'}
              </span>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-1 mb-2">
            {serviceCategories.map((category, index) => (
              <span 
                key={`${category.id}-${index}`}
                className={`text-xs ${
                  category.isPrimary
                    ? 'bg-primary/10 text-primary'
                    : 'bg-gray-bg text-gray-dark'
                } px-2 py-0.5 rounded-full`}
              >
                {category.name}
              </span>
            ))}
          </div>
          
          <div className="flex justify-between items-center">
            <div>
              {minPrice === maxPrice ? (
                <>
                  <span className="text-accent font-semibold">${minPrice}</span>
                  <span className="text-gray text-sm">/hour</span>
                </>
              ) : (
                <>
                  <span className="text-accent font-semibold">${minPrice}-${maxPrice}</span>
                  <span className="text-gray text-sm">/hour</span>
                </>
              )}
            </div>
            <button 
              className="bg-primary text-white font-medium text-sm px-4 py-1.5 rounded-lg"
              onClick={(e) => {
                e.stopPropagation();
                onClick();
              }}
            >
              Book Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssistantCard;
