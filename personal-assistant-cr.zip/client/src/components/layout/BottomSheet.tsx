import { FC, ReactNode, useState, useRef, useEffect } from 'react';

interface BottomSheetProps {
  children: ReactNode;
  initialHeight?: number;
  minHeight?: number;
  maxHeight?: number;
}

const BottomSheet: FC<BottomSheetProps> = ({ 
  children, 
  initialHeight = 300, 
  minHeight = 200, 
  maxHeight = window.innerHeight * 0.85 
}) => {
  const [height, setHeight] = useState(initialHeight);
  const [isDragging, setIsDragging] = useState(false);
  const [startY, setStartY] = useState(0);
  const [startHeight, setStartHeight] = useState(initialHeight);
  
  const sheetRef = useRef<HTMLDivElement>(null);
  
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    setIsDragging(true);
    setStartY(e.touches[0].clientY);
    setStartHeight(height);
  };
  
  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    
    const currentY = e.touches[0].clientY;
    const deltaY = currentY - startY;
    let newHeight = startHeight - deltaY;
    
    if (newHeight < minHeight) newHeight = minHeight;
    if (newHeight > maxHeight) newHeight = maxHeight;
    
    setHeight(newHeight);
  };
  
  const handleTouchEnd = () => {
    setIsDragging(false);
    
    // Snap to preset heights
    if (height < minHeight + 50) {
      setHeight(minHeight);
    } else if (height > maxHeight - 50) {
      setHeight(maxHeight);
    } else {
      // Snap to middle position
      setHeight(Math.round(window.innerHeight * 0.5));
    }
  };
  
  // Update maxHeight on window resize
  useEffect(() => {
    const handleResize = () => {
      const newMaxHeight = window.innerHeight * 0.85;
      if (height > newMaxHeight) {
        setHeight(newMaxHeight);
      }
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [height]);
  
  return (
    <div 
      ref={sheetRef}
      className="bottom-sheet bg-white rounded-t-3xl shadow-lg absolute bottom-0 left-0 right-0 z-20 overflow-hidden transition-transform"
      style={{ height: `${height}px` }}
    >
      <div 
        className="h-1.5 w-12 bg-gray-light rounded-full mx-auto mt-3 mb-2 cursor-grab"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      ></div>
      
      <div className="overflow-y-auto" style={{ height: `calc(100% - 20px)` }}>
        {children}
      </div>
    </div>
  );
};

export default BottomSheet;
