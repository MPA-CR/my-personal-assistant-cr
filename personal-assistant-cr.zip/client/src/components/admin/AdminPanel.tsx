import { FC, ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { Redirect } from 'wouter';

interface AdminPanelProps {
  children: ReactNode;
  title: string;
}

const AdminPanel: FC<AdminPanelProps> = ({ children, title }) => {
  const { user } = useAuth();
  const [location] = useLocation();
  
  if (!user || user.role !== 'admin') {
    return <Redirect to="/login" />;
  }

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="hidden md:flex md:flex-shrink-0">
        <div className="flex flex-col w-64 bg-white shadow">
          <div className="flex flex-col flex-1 pt-5 pb-4 overflow-y-auto">
            <div className="flex items-center flex-shrink-0 px-4 border-b pb-4">
              <h1 className="font-poppins font-bold text-lg text-primary">Admin Dashboard</h1>
            </div>
            <nav className="mt-5 flex-1 px-2 space-y-1">
              <Link href="/admin">
                <a
                  className={`${
                    location === '/admin'
                      ? 'bg-primary text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  <i className="ri-dashboard-line mr-3 text-lg"></i>
                  Dashboard
                </a>
              </Link>
              <Link href="/admin/assistants">
                <a
                  className={`${
                    location === '/admin/assistants'
                      ? 'bg-primary text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  <i className="ri-user-line mr-3 text-lg"></i>
                  Assistants
                </a>
              </Link>
              <Link href="/admin/bookings">
                <a
                  className={`${
                    location === '/admin/bookings'
                      ? 'bg-primary text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  <i className="ri-calendar-line mr-3 text-lg"></i>
                  Bookings
                </a>
              </Link>
              <Link href="/admin/services">
                <a
                  className={`${
                    location === '/admin/services'
                      ? 'bg-primary text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  <i className="ri-service-line mr-3 text-lg"></i>
                  Services
                </a>
              </Link>
            </nav>
          </div>
          <div className="flex-shrink-0 flex border-t border-gray-200 p-4">
            <Link href="/">
              <a className="flex-shrink-0 group block">
                <div className="flex items-center">
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-700 group-hover:text-gray-900">
                      Return to App
                    </p>
                  </div>
                </div>
              </a>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Mobile sidebar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-20 bg-white border-t border-gray-200">
        <div className="flex justify-around">
          <Link href="/admin">
            <a className={`${location === '/admin' ? 'text-primary' : 'text-gray-600'} flex flex-col items-center py-2 px-2`}>
              <i className="ri-dashboard-line text-xl"></i>
              <span className="text-xs">Dashboard</span>
            </a>
          </Link>
          <Link href="/admin/assistants">
            <a className={`${location === '/admin/assistants' ? 'text-primary' : 'text-gray-600'} flex flex-col items-center py-2 px-2`}>
              <i className="ri-user-line text-xl"></i>
              <span className="text-xs">Assistants</span>
            </a>
          </Link>
          <Link href="/admin/bookings">
            <a className={`${location === '/admin/bookings' ? 'text-primary' : 'text-gray-600'} flex flex-col items-center py-2 px-2`}>
              <i className="ri-calendar-line text-xl"></i>
              <span className="text-xs">Bookings</span>
            </a>
          </Link>
          <Link href="/admin/services">
            <a className={`${location === '/admin/services' ? 'text-primary' : 'text-gray-600'} flex flex-col items-center py-2 px-2`}>
              <i className="ri-service-line text-xl"></i>
              <span className="text-xs">Services</span>
            </a>
          </Link>
          <Link href="/">
            <a className="text-gray-600 flex flex-col items-center py-2 px-2">
              <i className="ri-arrow-left-line text-xl"></i>
              <span className="text-xs">App</span>
            </a>
          </Link>
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          <div className="py-6">
            <div className="px-4 sm:px-6 md:px-8">
              <h1 className="text-2xl font-semibold text-gray-900">{title}</h1>
            </div>
            <div className="mx-auto px-4 sm:px-6 md:px-8 mt-4 pb-20 md:pb-0">
              {children}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminPanel;
