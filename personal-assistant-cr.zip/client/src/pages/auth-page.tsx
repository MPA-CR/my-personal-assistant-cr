import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import LoginForm from '@/components/auth/LoginForm';
import RegisterForm from '@/components/auth/RegisterForm';
import { useAuth } from '@/hooks/useAuth';
import { ArrowLeft, UserRound, PersonStanding } from 'lucide-react';
import { Link } from 'wouter';

export default function AuthPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("login");
  
  const handleSuccess = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gradient-to-br from-blue-50 to-gray-100">
      {/* Left side - Form */}
      <div className="w-full md:w-1/2 p-6 flex items-center justify-center">
        <div className="w-full max-w-md">
          <div className="text-center mb-6 md:hidden">
            <div className="mb-4 flex justify-center">
              <div className="h-16 w-16 rounded-full object-cover border-4 border-white shadow-lg bg-cover bg-center" 
                   style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1496372412473-e8548ffd82bc?auto=format&fit=crop&w=150&q=80)' }} />
            </div>
            <h1 className="font-poppins text-xl font-bold text-gray-900 mb-1">My Personal Assistant</h1>
            <p className="text-gray-600 text-sm">Costa Rica</p>
          </div>
          
          <Card className="border-0 shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl">Welcome</CardTitle>
              <CardDescription>
                Access personal assistant services in Costa Rica
              </CardDescription>
            </CardHeader>
            
            <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
              <div className="px-6">
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="login">Sign In</TabsTrigger>
                  <TabsTrigger value="register">Create Account</TabsTrigger>
                </TabsList>
              </div>
              
              <CardContent>
                <TabsContent value="login" className="mt-0">
                  <LoginForm onSuccess={handleSuccess} />
                </TabsContent>
                
                <TabsContent value="register" className="mt-0">
                  <RegisterForm onSuccess={handleSuccess} />
                </TabsContent>
              </CardContent>
            </Tabs>
            
            <CardFooter className="flex flex-col space-y-4 pb-6">
              <div className="text-center">
                <Link href="/" className="text-sm text-gray-500 hover:text-gray-700 inline-flex items-center">
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Back to home
                </Link>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
      
      {/* Right side - Hero image and description */}
      <div className="hidden md:flex md:w-1/2 bg-blue-600 text-white p-12 flex-col justify-center items-center">
        <div className="mb-8">
          <div className="h-24 w-24 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center mb-6">
            <img 
              src="https://images.unsplash.com/photo-1496372412473-e8548ffd82bc?auto=format&fit=crop&w=150&q=80" 
              alt="Logo" 
              className="h-20 w-20 rounded-full object-cover" 
            />
          </div>
          <h1 className="text-3xl font-bold mb-2">My Personal Assistant</h1>
          <p className="text-blue-100">Costa Rica</p>
        </div>
        
        <div className="max-w-md space-y-8">
          <div className="flex items-start space-x-4">
            <div className="bg-white/10 p-3 rounded-lg">
              <UserRound className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-1">Find Local Assistants</h3>
              <p className="text-blue-100">Discover qualified personal assistants in your area for translation, security, and guidance services.</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-4">
            <div className="bg-white/10 p-3 rounded-lg">
              <PersonStanding className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-1">Work With Us</h3>
              <p className="text-blue-100">Join our team of professional assistants to offer your services and build your client base in Costa Rica.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}