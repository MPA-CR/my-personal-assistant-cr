import { FC } from 'react';
import { Link, useLocation } from 'wouter';
import { Home, MapPin, Calendar, MessageSquare, User } from 'lucide-react';
import { cn } from '@/lib/utils';

const BottomNavigation: FC = () => {
  const [location] = useLocation();

  const navItems = [
    { href: '/', icon: Home, label: 'Home' },
    { href: '/nearby', icon: MapPin, label: 'Nearby' },
    { href: '/bookings', icon: Calendar, label: 'Bookings' },
    { href: '/messages', icon: MessageSquare, label: 'Messages' },
    { href: '/profile', icon: User, label: 'Profile' }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-30 pb-safe-area-inset-bottom">
      <nav className="bg-white border-t border-gray-200 flex justify-around px-2 pt-2 pb-2 shadow-lg">
        {navItems.map(({ href, icon: Icon, label }) => {
          const isActive = location === href || 
                          (href !== '/' && location.startsWith(href));
          
          return (
            <Link 
              key={href}
              href={href} 
              className="flex flex-col items-center justify-center py-2 w-full"
            >
              <div className={cn(
                "flex items-center justify-center h-10 w-10 rounded-full transition-colors",
                isActive ? "bg-primary/10" : "transparent"
              )}>
                <Icon 
                  className={cn(
                    "h-5 w-5 transition-colors", 
                    isActive ? "text-primary" : "text-gray-500"
                  )} 
                />
              </div>
              <span 
                className={cn(
                  "text-xs font-medium mt-1 transition-colors", 
                  isActive ? "text-primary" : "text-gray-500"
                )}
              >
                {label}
              </span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
};

export default BottomNavigation;
