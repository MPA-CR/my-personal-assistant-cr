import { FC, useEffect, useState } from 'react';
import AppLayout from '@/components/layout/AppLayout';
import BottomSheet from '@/components/layout/BottomSheet';
import MapView from '@/components/map/MapView';
import ServiceCategories from '@/components/assistants/ServiceCategories';
import AssistantCard from '@/components/assistants/AssistantCard';
import AssistantDetail from '@/components/assistants/AssistantDetail';
import { useAssistants } from '@/hooks/useAssistants';
import { useLocation } from '@/hooks/useLocation';
import { useServices } from '@/hooks/useServices';
import { UserWithoutPassword, AssistantWithServices, MapMarker } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/hooks/useAuth';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

const Home: FC = () => {
  const { user } = useAuth();
  const { currentLocation, isLoadingLocation } = useLocation();
  const { data: categories = [], isLoading: isLoadingCategories } = useServices();
  const { 
    nearbyAssistants, 
    isLoading: isLoadingAssistants, 
    getAssistantServices 
  } = useAssistants();
  
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  const [selectedAssistant, setSelectedAssistant] = useState<AssistantWithServices | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [mapMarkers, setMapMarkers] = useState<MapMarker[]>([]);
  
  // Get filtered assistants based on selected category
  const filteredAssistants = selectedCategoryId
    ? nearbyAssistants.filter(assistant => 
        assistant.services.some(service => service.categoryId === selectedCategoryId)
      )
    : nearbyAssistants;
  
  useEffect(() => {
    // Create map markers from assistants
    if (nearbyAssistants.length > 0) {
      const markers: MapMarker[] = nearbyAssistants.map(assistant => {
        const primaryService = assistant.services[0];
        const category = categories.find(cat => cat.id === primaryService?.categoryId);
        
        const location = assistant.location as any;
        
        return {
          id: assistant.id,
          position: [location?.lat ?? 9.9281, location?.lng ?? -84.0907], // Default to San Jose
          type: category?.name.toLowerCase().replace(/\s+/g, '-') ?? 'general',
          user: assistant
        };
      });
      
      setMapMarkers(markers);
    }
  }, [nearbyAssistants, categories]);
  
  const handleCategoryChange = (categoryId: number | null) => {
    setSelectedCategoryId(categoryId);
  };
  
  const handleAssistantClick = async (assistant: UserWithoutPassword) => {
    try {
      const assistantWithServices = await getAssistantServices(assistant.id);
      setSelectedAssistant(assistantWithServices);
      setIsDetailModalOpen(true);
    } catch (error) {
      console.error("Failed to get assistant details:", error);
    }
  };
  
  const defaultCenter: [number, number] = currentLocation 
    ? [currentLocation.lat, currentLocation.lng] 
    : [9.9281, -84.0907]; // Default to San Jose, Costa Rica
  
  return (
    <AppLayout>
      {/* Map Component */}
      <MapView 
        markers={mapMarkers} 
        center={defaultCenter}
        onMarkerClick={handleAssistantClick}
      />
      
      {/* Bottom Sheet */}
      <BottomSheet
        initialHeight={window.innerHeight * 0.4}
        minHeight={200}
        maxHeight={window.innerHeight * 0.85}
      >
        {!user ? (
          <div className="p-4 flex flex-col items-center justify-center h-full">
            <i className="ri-user-line text-5xl text-gray-300 mb-4"></i>
            <h3 className="text-lg font-semibold mb-2">Sign in to book an assistant</h3>
            <p className="text-gray-500 mb-6 text-center">
              Create an account or sign in to find and book personal assistants in Costa Rica
            </p>
            <div className="flex space-x-4">
              <Button asChild variant="outline">
                <Link href="/auth">Sign In</Link>
              </Button>
              <Button asChild>
                <Link href="/auth">Sign Up</Link>
              </Button>
            </div>
          </div>
        ) : (
          <>
            {/* Service Categories */}
            <ServiceCategories 
              selectedCategory={selectedCategoryId} 
              onCategoryChange={handleCategoryChange} 
            />
            
            {/* Nearby Assistants */}
            <div className="px-4 py-2">
              <div className="flex justify-between items-center mb-3">
                <h2 className="font-poppins font-semibold text-lg">Nearby Assistants</h2>
                <div className="flex space-x-2">
                  <button className="bg-gray-bg p-1.5 rounded-md">
                    <i className="ri-filter-3-line text-gray-dark"></i>
                  </button>
                  <button className="bg-gray-bg p-1.5 rounded-md">
                    <i className="ri-sort-desc text-gray-dark"></i>
                  </button>
                </div>
              </div>
              
              <div className="space-y-4 max-h-[60vh] overflow-y-auto pb-16 scroll-container">
                {isLoadingAssistants || isLoadingCategories ? (
                  Array(3).fill(0).map((_, i) => (
                    <div key={i} className="bg-white rounded-xl shadow-sm p-3 border border-gray-light/50">
                      <div className="flex items-start">
                        <Skeleton className="w-16 h-16 rounded-lg mr-3" />
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <Skeleton className="h-5 w-32 mb-1" />
                              <Skeleton className="h-4 w-24 mb-2" />
                            </div>
                            <Skeleton className="h-4 w-10" />
                          </div>
                          <div className="flex flex-wrap gap-1 mb-3">
                            <Skeleton className="h-4 w-16 rounded-full" />
                            <Skeleton className="h-4 w-20 rounded-full" />
                          </div>
                          <div className="flex justify-between items-center">
                            <Skeleton className="h-5 w-16" />
                            <Skeleton className="h-8 w-24 rounded-lg" />
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : filteredAssistants.length > 0 ? (
                  filteredAssistants.map(assistant => (
                    <AssistantCard
                      key={assistant.id}
                      assistant={assistant}
                      categories={categories}
                      distance={
                        currentLocation && assistant.location
                          ? calculateDistance(
                              currentLocation.lat,
                              currentLocation.lng,
                              (assistant.location as any).lat,
                              (assistant.location as any).lng
                            )
                          : undefined
                      }
                      onClick={() => handleAssistantClick(assistant)}
                    />
                  ))
                ) : (
                  <div className="text-center py-6">
                    <i className="ri-search-line text-5xl text-gray-300 mb-2"></i>
                    <p className="text-gray-500">
                      {selectedCategoryId
                        ? "No assistants found for the selected category"
                        : isLoadingLocation
                          ? "Locating nearby assistants..."
                          : "No assistants available nearby"}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </BottomSheet>
      
      {/* Assistant Detail Modal */}
      <AssistantDetail
        assistant={selectedAssistant}
        categories={categories}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
      />
    </AppLayout>
  );
};

// Helper function to calculate distance between two coordinates
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c; // Distance in km
}

export default Home;
