import { FC, useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { AssistantWithServices } from '@/lib/types';
import { ServiceCategory, InsertBooking } from '@shared/schema';
import { useAuth } from '@/hooks/useAuth';
import { useBookings } from '@/hooks/useBookings';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from '@/hooks/useLocation';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { addHours, format } from 'date-fns';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  assistant: AssistantWithServices;
  serviceId: number | null;
  categories: ServiceCategory[];
}

const BookingModal: FC<BookingModalProps> = ({ 
  isOpen, 
  onClose, 
  assistant,
  serviceId,
  categories
}) => {
  const { user } = useAuth();
  const { currentLocation } = useLocation();
  const { createBooking, isCreating } = useBookings();
  const { toast } = useToast();
  
  const [notes, setNotes] = useState('');
  const [selectedDate] = useState(new Date());
  const [selectedTime] = useState('10:00 AM');
  const [duration] = useState(4); // hours
  
  const selectedService = assistant.services.find(s => s.id === serviceId) || assistant.services[0];
  const serviceCategory = categories.find(c => c.id === selectedService.categoryId);
  
  const startTime = new Date(selectedDate);
  const [hours, minutes] = selectedTime.split(':').map(part => parseInt(part));
  startTime.setHours(hours < 12 ? hours : hours, minutes);
  
  const endTime = addHours(startTime, duration);
  
  const serviceFee = selectedService.pricePerHour * duration;
  const appFee = serviceFee * 0.1; // 10% app fee
  const totalAmount = serviceFee + appFee;
  
  const handleBooking = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to book a service",
        variant: "destructive"
      });
      return;
    }
    
    if (!currentLocation) {
      toast({
        title: "Location required",
        description: "We need your location to book a service",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const bookingData: InsertBooking = {
        clientId: user.id,
        assistantId: assistant.id,
        serviceId: selectedService.id,
        startTime,
        endTime,
        location: {
          ...currentLocation,
          address: "Manuel Antonio National Park" // In a real app, this would be selected by the user
        },
        status: "pending",
        totalAmount,
        notes
      };
      
      await createBooking(bookingData);
      
      toast({
        title: "Booking successful",
        description: "Your booking has been confirmed",
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Booking failed",
        description: (error as Error).message,
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <div className="p-1">
          <div className="flex justify-between items-center mb-5">
            <h2 className="font-poppins font-semibold text-xl">Book Assistant</h2>
          </div>
          
          <div className="mb-5">
            <div className="flex items-center mb-4">
              <div 
                className="w-12 h-12 rounded-full bg-gray-200 mr-3 bg-cover bg-center"
                style={{ 
                  backgroundImage: assistant.profileImage 
                    ? `url(${assistant.profileImage})` 
                    : 'none'
                }}
              >
                {!assistant.profileImage && (
                  <div className="w-full h-full flex items-center justify-center">
                    <i className="ri-user-line text-gray-400"></i>
                  </div>
                )}
              </div>
              <div>
                <h3 className="font-medium">{assistant.fullName}</h3>
                <div className="flex items-center text-sm text-gray">
                  <i className={`${serviceCategory?.icon || 'ri-service-line'} mr-1`}></i>
                  <span>{serviceCategory?.name || 'Service'}</span>
                  <span className="mx-1">•</span>
                  <i className="ri-star-fill text-accent text-xs"></i>
                  <span>
                    {assistant.avgRating 
                      ? assistant.avgRating.toFixed(1) 
                      : 'New'}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-bg p-3 rounded-lg mb-4">
              <div className="flex justify-between mb-2">
                <div className="text-gray">Date</div>
                <div className="font-medium">
                  {format(selectedDate, 'EEEE, MMM d, yyyy')}
                </div>
              </div>
              <div className="flex justify-between">
                <div className="text-gray">Time</div>
                <div className="font-medium">
                  {selectedTime} - {format(endTime, 'h:mm a')} ({duration} hours)
                </div>
              </div>
            </div>
            
            <div className="bg-gray-bg p-3 rounded-lg mb-4">
              <div className="flex justify-between mb-2">
                <div className="text-gray">Service</div>
                <div className="font-medium">
                  {serviceCategory?.name || 'Service'}
                </div>
              </div>
              <div className="flex justify-between">
                <div className="text-gray">Location</div>
                <div className="font-medium">Manuel Antonio National Park</div>
              </div>
            </div>
            
            <div className="mb-4">
              <label className="block mb-2 text-sm text-gray-dark">Additional Notes</label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Provide any special requirements or information"
                className="h-20 text-sm"
              />
            </div>
          </div>
          
          <div className="border-t border-gray-light pt-4 mb-4">
            <div className="flex justify-between mb-2">
              <div>Service Fee ({duration} hours × ${selectedService.pricePerHour})</div>
              <div className="font-medium">${serviceFee.toFixed(2)}</div>
            </div>
            <div className="flex justify-between mb-2">
              <div>App Service Fee</div>
              <div className="font-medium">${appFee.toFixed(2)}</div>
            </div>
            <div className="flex justify-between font-semibold text-lg mt-3">
              <div>Total</div>
              <div className="text-accent">${totalAmount.toFixed(2)}</div>
            </div>
          </div>
          
          <div className="flex flex-col space-y-3">
            <Button 
              className="w-full" 
              onClick={handleBooking}
              disabled={isCreating}
            >
              {isCreating ? "Processing..." : "Confirm & Pay"}
            </Button>
            <Button 
              variant="outline"
              className="w-full" 
              onClick={onClose}
            >
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BookingModal;
