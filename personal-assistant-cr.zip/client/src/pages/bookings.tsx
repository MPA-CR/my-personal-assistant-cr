import { FC, useState } from 'react';
import AppLayout from '@/components/layout/AppLayout';
import { useAuth } from '@/hooks/useAuth';
import { useBookings } from '@/hooks/useBookings';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Booking } from '@shared/schema';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { format } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

const Bookings: FC = () => {
  const { user } = useAuth();
  const { bookings, isLoading, cancelBooking } = useBookings();
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const { toast } = useToast();
  
  if (!user) {
    return (
      <AppLayout>
        <div className="p-6 flex flex-col items-center justify-center min-h-[70vh]">
          <i className="ri-calendar-line text-5xl text-gray-300 mb-4"></i>
          <h3 className="text-xl font-semibold mb-2">Sign in to view bookings</h3>
          <p className="text-gray-500 mb-6 text-center">
            You need to be signed in to view and manage your bookings
          </p>
          <Button asChild>
            <Link href="/login">Sign In</Link>
          </Button>
        </div>
      </AppLayout>
    );
  }
  
  const pendingBookings = bookings.filter(booking => booking.status === 'pending' || booking.status === 'confirmed');
  const pastBookings = bookings.filter(booking => booking.status === 'completed' || booking.status === 'cancelled');
  
  const formatDate = (date: Date) => {
    return format(new Date(date), 'MMM d, yyyy');
  };
  
  const formatTime = (date: Date) => {
    return format(new Date(date), 'h:mm a');
  };
  
  const handleCancelBooking = async () => {
    if (!selectedBooking) return;
    
    try {
      setIsCancelling(true);
      await cancelBooking(selectedBooking.id);
      
      toast({
        title: "Booking Cancelled",
        description: "Your booking has been cancelled successfully",
      });
      
      setIsDetailsOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: (error as Error).message,
        variant: "destructive",
      });
    } finally {
      setIsCancelling(false);
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline">Pending</Badge>;
      case 'confirmed':
        return <Badge variant="secondary">Confirmed</Badge>;
      case 'completed':
        return <Badge>Completed</Badge>;
      case 'cancelled':
        return <Badge variant="destructive">Cancelled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  const openBookingDetails = (booking: Booking) => {
    setSelectedBooking(booking);
    setIsDetailsOpen(true);
  };

  return (
    <AppLayout>
      <div className="p-4">
        <h1 className="font-poppins text-2xl font-semibold mb-4">My Bookings</h1>
        
        <Tabs defaultValue="upcoming">
          <TabsList className="mb-4 w-full grid grid-cols-2">
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="past">Past</TabsTrigger>
          </TabsList>
          
          <TabsContent value="upcoming">
            {isLoading ? (
              Array(3).fill(0).map((_, i) => (
                <Card key={i} className="mb-4">
                  <CardContent className="pt-6 pb-4">
                    <div className="flex justify-between mb-2">
                      <Skeleton className="h-6 w-32" />
                      <Skeleton className="h-6 w-20" />
                    </div>
                    <Skeleton className="h-4 w-40 mb-4" />
                    <div className="flex justify-between">
                      <Skeleton className="h-5 w-20" />
                      <Skeleton className="h-8 w-24 rounded-md" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : pendingBookings.length > 0 ? (
              pendingBookings.map(booking => (
                <Card key={booking.id} className="mb-4">
                  <CardContent className="pt-6 pb-4">
                    <div className="flex justify-between mb-1">
                      <h3 className="font-semibold">Booking #{booking.id}</h3>
                      {getStatusBadge(booking.status)}
                    </div>
                    <p className="text-gray-500 text-sm mb-3">
                      {formatDate(booking.startTime)} • {formatTime(booking.startTime)} - {formatTime(booking.endTime)}
                    </p>
                    <div className="flex justify-between items-center">
                      <div className="text-accent font-semibold">${booking.totalAmount.toFixed(2)}</div>
                      <Button size="sm" onClick={() => openBookingDetails(booking)}>
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-12">
                <i className="ri-calendar-2-line text-5xl text-gray-300 mb-4"></i>
                <h3 className="text-lg font-medium mb-2">No upcoming bookings</h3>
                <p className="text-gray-500 mb-6">You don't have any upcoming bookings</p>
                <Button asChild>
                  <Link href="/">Find an Assistant</Link>
                </Button>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="past">
            {isLoading ? (
              Array(3).fill(0).map((_, i) => (
                <Card key={i} className="mb-4">
                  <CardContent className="pt-6 pb-4">
                    <div className="flex justify-between mb-2">
                      <Skeleton className="h-6 w-32" />
                      <Skeleton className="h-6 w-20" />
                    </div>
                    <Skeleton className="h-4 w-40 mb-4" />
                    <div className="flex justify-between">
                      <Skeleton className="h-5 w-20" />
                      <Skeleton className="h-8 w-24 rounded-md" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : pastBookings.length > 0 ? (
              pastBookings.map(booking => (
                <Card key={booking.id} className="mb-4">
                  <CardContent className="pt-6 pb-4">
                    <div className="flex justify-between mb-1">
                      <h3 className="font-semibold">Booking #{booking.id}</h3>
                      {getStatusBadge(booking.status)}
                    </div>
                    <p className="text-gray-500 text-sm mb-3">
                      {formatDate(booking.startTime)} • {formatTime(booking.startTime)} - {formatTime(booking.endTime)}
                    </p>
                    <div className="flex justify-between items-center">
                      <div className="text-accent font-semibold">${booking.totalAmount.toFixed(2)}</div>
                      <Button size="sm" variant="outline" onClick={() => openBookingDetails(booking)}>
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-12">
                <i className="ri-history-line text-5xl text-gray-300 mb-4"></i>
                <h3 className="text-lg font-medium mb-2">No past bookings</h3>
                <p className="text-gray-500 mb-6">You don't have any past bookings</p>
                <Button asChild>
                  <Link href="/">Find an Assistant</Link>
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Booking Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Booking Details</DialogTitle>
            <DialogDescription>
              View your booking information
            </DialogDescription>
          </DialogHeader>
          
          {selectedBooking && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">Booking #{selectedBooking.id}</h3>
                {getStatusBadge(selectedBooking.status)}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">Date</p>
                  <p>{formatDate(selectedBooking.startTime)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Time</p>
                  <p>{formatTime(selectedBooking.startTime)} - {formatTime(selectedBooking.endTime)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Service ID</p>
                  <p>{selectedBooking.serviceId}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500">Amount</p>
                  <p className="font-semibold">${selectedBooking.totalAmount.toFixed(2)}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Location</p>
                <p>{selectedBooking.location.address || 'No address provided'}</p>
              </div>
              
              {selectedBooking.notes && (
                <div>
                  <p className="text-sm font-medium text-gray-500">Notes</p>
                  <p>{selectedBooking.notes}</p>
                </div>
              )}
              
              <DialogFooter>
                {selectedBooking.status === 'pending' || selectedBooking.status === 'confirmed' ? (
                  <>
                    <Button 
                      variant="destructive" 
                      onClick={handleCancelBooking}
                      disabled={isCancelling}
                    >
                      {isCancelling ? "Cancelling..." : "Cancel Booking"}
                    </Button>
                    <Button onClick={() => setIsDetailsOpen(false)}>
                      Close
                    </Button>
                  </>
                ) : (
                  <Button onClick={() => setIsDetailsOpen(false)}>
                    Close
                  </Button>
                )}
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
};

export default Bookings;
