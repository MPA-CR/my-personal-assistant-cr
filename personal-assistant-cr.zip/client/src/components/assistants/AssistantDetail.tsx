import { FC, useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { AssistantWithServices } from '@/lib/types';
import { ServiceCategory } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';
import { Review } from '@shared/schema';
import { format } from 'date-fns';
import BookingModal from './BookingModal';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

interface AssistantDetailProps {
  assistant: AssistantWithServices | null;
  categories: ServiceCategory[];
  isOpen: boolean;
  onClose: () => void;
}

const AssistantDetail: FC<AssistantDetailProps> = ({ 
  assistant, 
  categories,
  isOpen, 
  onClose 
}) => {
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedServiceId, setSelectedServiceId] = useState<number | null>(null);
  
  const { data: reviews, isLoading: isLoadingReviews } = useQuery<Review[]>({
    queryKey: ['/api/reviews', assistant?.id],
    enabled: isOpen && !!assistant,
  });
  
  const handleBookNow = (serviceId: number) => {
    setSelectedServiceId(serviceId);
    setIsBookingModalOpen(true);
  };
  
  if (!assistant) return null;

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md p-0 h-[90vh] max-h-[90vh] overflow-hidden">
          <div className="flex flex-col h-full">
            <header className="bg-white p-4 shadow-sm flex items-center sticky top-0 z-10">
              <button className="mr-3" onClick={onClose}>
                <i className="ri-arrow-left-line text-xl"></i>
              </button>
              <h1 className="font-poppins font-semibold text-lg">Assistant Profile</h1>
            </header>
            
            <div className="overflow-y-auto flex-1 pb-16">
              <div className="relative mb-5">
                <div 
                  className="w-full h-48 bg-gray-200 bg-cover bg-center"
                  style={{ 
                    backgroundImage: assistant.profileImage 
                      ? `url(${assistant.profileImage})` 
                      : 'none'
                  }}
                >
                  {!assistant.profileImage && (
                    <div className="w-full h-full flex items-center justify-center">
                      <i className="ri-user-line text-gray-400 text-5xl"></i>
                    </div>
                  )}
                </div>
                <div className="absolute bottom-4 left-4 bg-white px-3 py-1.5 rounded-lg shadow flex items-center">
                  <i className="ri-star-fill text-accent mr-1"></i>
                  <span className="font-semibold">
                    {assistant.avgRating 
                      ? assistant.avgRating.toFixed(1) 
                      : 'New'}
                  </span>
                  <span className="text-gray text-sm ml-1">
                    ({reviews?.length || 0} reviews)
                  </span>
                </div>
                <Button 
                  size="icon"
                  variant="outline" 
                  className="absolute top-4 right-4 bg-white h-9 w-9 rounded-full"
                >
                  <i className="ri-share-line text-gray-dark"></i>
                </Button>
              </div>
              
              <div className="px-4 mb-6">
                <h2 className="font-poppins font-semibold text-xl mb-1">{assistant.fullName}</h2>
                <div className="flex items-center text-gray mb-3">
                  <i className="ri-map-pin-line mr-1"></i>
                  <span>Costa Rica</span>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {assistant.services.map(service => {
                    const category = categories.find(c => c.id === service.categoryId);
                    return (
                      <span 
                        key={service.id}
                        className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm"
                      >
                        {category?.name || 'Service'}
                      </span>
                    );
                  })}
                </div>
                
                <p className="text-gray-dark">
                  {assistant.bio || 'Professional assistant with expertise in various services to help you enjoy your stay in Costa Rica.'}
                </p>
              </div>
              
              <div className="px-4 mb-6">
                <h3 className="font-poppins font-semibold text-lg mb-3">Services & Pricing</h3>
                <div className="space-y-3">
                  {assistant.services.map(service => {
                    const category = categories.find(c => c.id === service.categoryId);
                    return (
                      <div 
                        key={service.id}
                        className="flex justify-between items-center p-3 bg-gray-bg rounded-lg"
                      >
                        <div className="flex items-center">
                          <i className={`${category?.icon || 'ri-service-line'} text-primary bg-primary/10 p-2 rounded-lg mr-3`}></i>
                          <span>{category?.name || 'Service'}</span>
                        </div>
                        <div className="font-semibold">${service.pricePerHour}/hour</div>
                      </div>
                    );
                  })}
                </div>
              </div>
              
              <div className="px-4 mb-6">
                <h3 className="font-poppins font-semibold text-lg mb-3">Reviews</h3>
                
                {isLoadingReviews ? (
                  <div className="space-y-4">
                    {Array(2).fill(0).map((_, index) => (
                      <div key={index} className="border-b border-gray-light pb-4">
                        <div className="flex justify-between mb-2">
                          <Skeleton className="h-4 w-32" />
                          <Skeleton className="h-4 w-16" />
                        </div>
                        <Skeleton className="h-4 w-full mb-1" />
                        <Skeleton className="h-4 w-4/5" />
                      </div>
                    ))}
                  </div>
                ) : reviews && reviews.length > 0 ? (
                  <div className="space-y-4">
                    {reviews.slice(0, 3).map(review => (
                      <div key={review.id} className="border-b border-gray-light pb-4">
                        <div className="flex justify-between mb-1">
                          <div className="font-medium">Client {review.clientId}</div>
                          <div className="flex items-center">
                            <i className="ri-star-fill text-accent"></i>
                            <span className="ml-1">{review.rating.toFixed(1)}</span>
                          </div>
                        </div>
                        <p className="text-gray-dark text-sm">
                          {review.comment || 'Great service!'}
                        </p>
                        <p className="text-xs text-gray mt-1">
                          {format(new Date(review.createdAt), 'MMM d, yyyy')}
                        </p>
                      </div>
                    ))}
                    
                    {reviews.length > 3 && (
                      <button className="w-full text-primary font-medium py-2 mt-2">
                        See all reviews
                      </button>
                    )}
                  </div>
                ) : (
                  <p className="text-gray text-center py-4">No reviews yet</p>
                )}
              </div>
              
              <div className="px-4 mb-6">
                <h3 className="font-poppins font-semibold text-lg mb-3">Availability</h3>
                <div className="bg-gray-bg p-3 rounded-lg">
                  <div className="flex space-x-2 mb-4 overflow-x-auto pb-2">
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((day, i) => {
                      const date = new Date();
                      date.setDate(date.getDate() + i);
                      return (
                        <div 
                          key={day}
                          className={`flex flex-col items-center min-w-[50px] p-2 rounded-lg ${
                            i === 1 ? 'bg-primary text-white' : 'bg-white'
                          }`}
                        >
                          <span className="text-xs text-gray mb-1">{day}</span>
                          <span className="font-medium">{date.getDate()}</span>
                        </div>
                      );
                    })}
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {[
                      '8:00 AM', '10:00 AM', '12:00 PM', 
                      '2:00 PM', '4:00 PM', '6:00 PM'
                    ].map((time, i) => (
                      <div 
                        key={time}
                        className={`py-1.5 px-3 rounded-lg text-sm ${
                          i === 1 ? 'bg-primary text-white' : 
                          i === 4 ? 'bg-gray-300 text-gray' : 'bg-white'
                        }`}
                      >
                        {time}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="sticky bottom-0 left-0 right-0 pt-3 pb-6 px-4 bg-white shadow-lg border-t border-gray-light">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <span className="text-accent font-semibold text-lg">
                    ${Math.min(...assistant.services.map(s => s.pricePerHour))}
                  </span>
                  <span className="text-gray">/hour</span>
                </div>
                <button className="flex items-center text-primary">
                  <i className="ri-message-3-line mr-1"></i>
                  <span>Message</span>
                </button>
              </div>
              <Button 
                className="w-full py-6" 
                onClick={() => {
                  if (assistant.services.length > 0) {
                    handleBookNow(assistant.services[0].id);
                  }
                }}
              >
                Book Now
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      <BookingModal 
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        assistant={assistant}
        serviceId={selectedServiceId}
        categories={categories}
      />
    </>
  );
};

export default AssistantDetail;
