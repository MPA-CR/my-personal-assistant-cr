import { FC, useEffect, useState, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { MapMarker } from '@/lib/types';
import { UserWithoutPassword } from '@/lib/types';
import { Button } from '@/components/ui/button';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix Leaflet default marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom marker icons
const createCustomIcon = (type: string) => {
  let color = '';
  let icon = '';
  
  if (type === 'translator') {
    color = '#2D9CDB';
    icon = 'ri-translate-2-line';
  } else if (type === 'security') {
    color = '#F2994A';
    icon = 'ri-shield-check-line';
  } else if (type === 'tour-guide') {
    color = '#27AE60';
    icon = 'ri-route-line';
  } else if (type === 'driver') {
    color = '#9B51E0';
    icon = 'ri-car-line';
  } else if (type === 'chef') {
    color = '#EB5757';
    icon = 'ri-restaurant-line';
  } else {
    color = '#2D9CDB';
    icon = 'ri-user-line';
  }
  
  return L.divIcon({
    html: `<div style="background-color: ${color}; color: white;" class="flex items-center justify-center h-10 w-10 rounded-full shadow-lg">
            <i class="${icon}"></i>
           </div>`,
    className: '',
    iconSize: [40, 40],
    iconAnchor: [20, 20],
  });
};

interface RecenterProps {
  position: [number, number];
}

const Recenter: FC<RecenterProps> = ({ position }) => {
  const map = useMap();
  
  useEffect(() => {
    map.setView(position);
  }, [position, map]);
  
  return null;
};

interface MapViewProps {
  markers: MapMarker[];
  center: [number, number];
  onMarkerClick: (assistant: UserWithoutPassword) => void;
}

const MapView: FC<MapViewProps> = ({ markers, center, onMarkerClick }) => {
  const [position, setPosition] = useState<[number, number]>(center);
  const mapRef = useRef<L.Map | null>(null);
  
  const handleLocationFound = (e: L.LocationEvent) => {
    const { lat, lng } = e.latlng;
    setPosition([lat, lng]);
  };
  
  const handleLocationClick = () => {
    if (mapRef.current) {
      mapRef.current.locate({ setView: true, maxZoom: 16 });
    }
  };
  
  useEffect(() => {
    if (mapRef.current) {
      mapRef.current.on('locationfound', handleLocationFound);
    }
    
    return () => {
      if (mapRef.current) {
        mapRef.current.off('locationfound', handleLocationFound);
      }
    };
  }, [mapRef.current]);
  
  return (
    <div className="map-container flex-1 z-10 relative">
      <MapContainer 
        center={center} 
        zoom={13} 
        style={{ height: '100%', width: '100%' }}
        whenCreated={map => { mapRef.current = map; }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        
        <Recenter position={position} />
        
        {markers.map(marker => (
          <Marker 
            key={marker.id}
            position={marker.position}
            icon={createCustomIcon(marker.type)}
            eventHandlers={{
              click: () => onMarkerClick(marker.user)
            }}
          >
            <Popup>
              <div className="text-center">
                <h3 className="font-semibold">{marker.user.fullName}</h3>
                <p className="text-sm text-gray-600">{marker.type}</p>
                <Button 
                  size="sm" 
                  className="mt-2" 
                  onClick={() => onMarkerClick(marker.user)}
                >
                  View Profile
                </Button>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
      
      <button 
        className="absolute right-4 bottom-40 bg-white p-3 rounded-full shadow-lg"
        onClick={handleLocationClick}
      >
        <i className="ri-focus-3-line text-gray-dark"></i>
      </button>
    </div>
  );
};

export default MapView;
