import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { ServiceCategory, InsertServiceCategory, Service, InsertService } from '@shared/schema';

export const useServices = () => {
  // Get service categories
  const { 
    data: categories = [], 
    isLoading: isLoadingCategories,
    error: categoriesError 
  } = useQuery<ServiceCategory[]>({
    queryKey: ['/api/service-categories'],
  });
  
  // Get services
  const { 
    data: services = [], 
    isLoading: isLoadingServices,
    error: servicesError 
  } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });
  
  // Create service category mutation
  const createCategoryMutation = useMutation({
    mutationFn: async (categoryData: InsertServiceCategory) => {
      const response = await apiRequest('POST', '/api/service-categories', categoryData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/service-categories'] });
    },
  });
  
  // Create service mutation
  const createServiceMutation = useMutation({
    mutationFn: async (serviceData: InsertService) => {
      const response = await apiRequest('POST', '/api/services', serviceData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/services'] });
    },
  });
  
  // Get services by category
  const getServicesByCategory = (categoryId: number) => {
    return services.filter(service => service.categoryId === categoryId);
  };
  
  // Get services by assistant
  const getServicesByAssistant = (assistantId: number) => {
    return services.filter(service => service.assistantId === assistantId);
  };
  
  // Create service category function
  const createCategory = async (categoryData: InsertServiceCategory) => {
    return createCategoryMutation.mutateAsync(categoryData);
  };
  
  // Create service function
  const createService = async (serviceData: InsertService) => {
    return createServiceMutation.mutateAsync(serviceData);
  };
  
  return {
    data: categories,
    services,
    isLoading: isLoadingCategories,
    error: categoriesError,
    isLoadingServices,
    servicesError,
    getServicesByCategory,
    getServicesByAssistant,
    createCategory,
    isCreatingCategory: createCategoryMutation.isPending,
    createService,
    isCreatingService: createServiceMutation.isPending
  };
};
