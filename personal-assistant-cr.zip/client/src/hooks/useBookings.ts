import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Booking, InsertBooking } from '@shared/schema';
import { useAuth } from '@/hooks/useAuth';

export const useBookings = () => {
  const { user } = useAuth();
  
  // Get user bookings
  const { 
    data: bookings = [], 
    isLoading,
    error 
  } = useQuery<Booking[]>({
    queryKey: ['/api/bookings'],
    enabled: !!user,
  });
  
  // Create booking mutation
  const createBookingMutation = useMutation({
    mutationFn: async (bookingData: InsertBooking) => {
      const response = await apiRequest('POST', '/api/bookings', bookingData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
    },
  });
  
  // Cancel booking mutation
  const cancelBookingMutation = useMutation({
    mutationFn: async (bookingId: number) => {
      const response = await apiRequest('PATCH', `/api/bookings/${bookingId}`, {
        status: 'cancelled'
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
    },
  });
  
  // Create booking function
  const createBooking = async (bookingData: InsertBooking) => {
    return createBookingMutation.mutateAsync(bookingData);
  };
  
  // Cancel booking function
  const cancelBooking = async (bookingId: number) => {
    return cancelBookingMutation.mutateAsync(bookingId);
  };
  
  return {
    bookings,
    isLoading,
    error,
    createBooking,
    isCreating: createBookingMutation.isPending,
    cancelBooking,
    isCancelling: cancelBookingMutation.isPending
  };
};
