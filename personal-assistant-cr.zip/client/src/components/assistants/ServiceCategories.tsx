import { FC, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { ServiceCategory } from '@shared/schema';

interface ServiceCategoriesProps {
  selectedCategory: number | null;
  onCategoryChange: (categoryId: number | null) => void;
}

const ServiceCategories: FC<ServiceCategoriesProps> = ({ 
  selectedCategory, 
  onCategoryChange 
}) => {
  const { data: categories, isLoading } = useQuery<ServiceCategory[]>({
    queryKey: ['/api/service-categories'],
  });

  return (
    <div className="px-4 py-3">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-poppins font-semibold text-lg">Services</h2>
        <button className="text-primary text-sm font-medium">View All</button>
      </div>
      
      <div className="scroll-container overflow-x-auto whitespace-nowrap pb-2">
        <div className="inline-flex space-x-3">
          {isLoading ? (
            Array(6).fill(0).map((_, index) => (
              <div key={index} className="flex flex-col items-center">
                <Skeleton className="w-14 h-14 rounded-full mb-1" />
                <Skeleton className="w-16 h-3" />
              </div>
            ))
          ) : (
            <>
              {categories?.map(category => (
                <div key={category.id} className="flex flex-col items-center">
                  <div
                    className={`service-icon w-14 h-14 rounded-full flex items-center justify-center mb-1 cursor-pointer ${
                      selectedCategory === category.id
                        ? 'bg-primary text-white'
                        : 'bg-gray-bg text-gray-dark'
                    }`}
                    onClick={() => onCategoryChange(
                      selectedCategory === category.id ? null : category.id
                    )}
                  >
                    <i className={`${category.icon} text-lg`}></i>
                  </div>
                  <span className="text-xs">{category.name}</span>
                </div>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ServiceCategories;
