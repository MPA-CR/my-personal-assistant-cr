import { FC } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Link } from 'wouter';

interface HeaderProps {
  onMenuClick: () => void;
}

const Header: FC<HeaderProps> = ({ onMenuClick }) => {
  const { user } = useAuth();

  return (
    <header className="bg-white p-4 shadow-sm z-20 relative flex items-center justify-between">
      <div className="flex items-center">
        <button className="mr-3" onClick={onMenuClick}>
          <i className="ri-menu-line text-xl"></i>
        </button>
        <Link href="/">
          <h1 className="font-poppins font-semibold text-lg cursor-pointer">My Personal Assistant</h1>
        </Link>
      </div>
      <div className="flex items-center space-x-3">
        <button className="bg-gray-bg p-1.5 rounded-full">
          <i className="ri-global-line text-lg"></i>
        </button>
        <button className="bg-gray-bg p-1.5 rounded-full">
          <i className="ri-notification-3-line text-lg"></i>
        </button>
        {user && (
          <Link href="/profile">
            <div className="h-8 w-8 rounded-full bg-gray-300 cursor-pointer flex items-center justify-center overflow-hidden">
              {user.profileImage ? (
                <div 
                  className="h-full w-full bg-cover bg-center" 
                  style={{ backgroundImage: `url(${user.profileImage})` }}
                />
              ) : (
                <i className="ri-user-line text-gray-600"></i>
              )}
            </div>
          </Link>
        )}
      </div>
    </header>
  );
};

export default Header;
