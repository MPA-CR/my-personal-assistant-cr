import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { UserWithoutPassword, AssistantWithServices } from '@/lib/types';
import { useLocation } from '@/hooks/useLocation';
import { Location } from '@shared/schema';

export const useAssistants = () => {
  const { currentLocation } = useLocation();
  const [radius, setRadius] = useState(10); // Default 10 km
  
  // Get nearby assistants based on current location
  const { 
    data: nearbyAssistants = [], 
    isLoading,
    error,
    refetch
  } = useQuery<AssistantWithServices[]>({
    queryKey: ['/api/assistants/nearby'],
    enabled: false, // We'll manually trigger the fetch with the right params
    queryFn: async () => {
      if (!currentLocation) {
        return [];
      }
      
      try {
        const response = await apiRequest(
          'GET', 
          `/api/assistants/nearby?lat=${currentLocation.lat}&lng=${currentLocation.lng}&radius=${radius}`
        );
        
        const data = await response.json();
        
        // Transform UserWithoutPassword[] to AssistantWithServices[]
        return data.map((assistant: UserWithoutPassword) => ({
          ...assistant,
          services: [] // Services will be populated on demand
        }));
      } catch (error) {
        console.error("Error fetching nearby assistants:", error);
        return [];
      }
    }
  });
  
  // Trigger the fetch when the location or radius changes
  useEffect(() => {
    if (currentLocation) {
      refetch();
    }
  }, [currentLocation, radius, refetch]);
  
  // Get assistant services
  const getAssistantServices = async (assistantId: number): Promise<AssistantWithServices> => {
    // Check if we already have this assistant with services in the cache
    const existingAssistant = nearbyAssistants.find(a => a.id === assistantId);
    
    if (existingAssistant && existingAssistant.services.length > 0) {
      return existingAssistant;
    }
    
    try {
      // Get assistant details
      const assistantResponse = await apiRequest('GET', `/api/users/${assistantId}`);
      
      if (!assistantResponse.ok) {
        throw new Error('Failed to fetch assistant details');
      }
      
      const assistant = await assistantResponse.json();
      
      // Get assistant services
      const servicesResponse = await apiRequest('GET', `/api/services?assistantId=${assistantId}`);
      
      if (!servicesResponse.ok) {
        throw new Error('Failed to fetch assistant services');
      }
      
      const services = await servicesResponse.json();
      
      // Combine assistant details with services
      const assistantWithServices: AssistantWithServices = {
        ...assistant,
        services
      };
      
      // Update the cache
      queryClient.setQueryData(
        ['/api/assistants/nearby'], 
        (oldData: AssistantWithServices[] = []) => {
          return oldData.map(a => 
            a.id === assistantId ? assistantWithServices : a
          );
        }
      );
      
      return assistantWithServices;
    } catch (error) {
      console.error("Error getting assistant services:", error);
      throw error;
    }
  };
  
  // Filter assistants by service category
  const filterByCategory = (categoryId: number) => {
    return nearbyAssistants.filter(assistant => 
      assistant.services.some(service => service.categoryId === categoryId)
    );
  };
  
  // Change search radius
  const changeRadius = (newRadius: number) => {
    setRadius(newRadius);
  };
  
  return {
    nearbyAssistants,
    isLoading,
    error,
    getAssistantServices,
    filterByCategory,
    changeRadius,
    radius
  };
};
