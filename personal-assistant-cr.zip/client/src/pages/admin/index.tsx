import { FC } from 'react';
import AdminPanel from '@/components/admin/AdminPanel';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { User, Booking, Service } from '@shared/schema';
import { Link } from 'wouter';

const AdminDashboard: FC = () => {
  const { data: users } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });

  const { data: bookings } = useQuery<Booking[]>({
    queryKey: ['/api/bookings'],
  });

  const { data: services } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });

  const assistantsCount = users?.filter(user => user.role === 'assistant').length || 0;
  const clientsCount = users?.filter(user => user.role === 'client').length || 0;
  const pendingBookingsCount = bookings?.filter(booking => booking.status === 'pending').length || 0;
  const completedBookingsCount = bookings?.filter(booking => booking.status === 'completed').length || 0;
  const totalRevenue = bookings?.reduce((sum, booking) => sum + booking.totalAmount, 0) || 0;

  return (
    <AdminPanel title="Dashboard">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Assistants</CardTitle>
            <i className="ri-user-line text-xl text-gray-400"></i>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{assistantsCount}</div>
            <p className="text-xs text-muted-foreground mt-1">
              <Link href="/admin/assistants" className="text-primary hover:underline">
                View all assistants
              </Link>
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
            <i className="ri-user-heart-line text-xl text-gray-400"></i>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{clientsCount}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Active users on the platform
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Bookings</CardTitle>
            <i className="ri-calendar-line text-xl text-gray-400"></i>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingBookingsCount}</div>
            <p className="text-xs text-muted-foreground mt-1">
              <Link href="/admin/bookings" className="text-primary hover:underline">
                Manage bookings
              </Link>
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Bookings</CardTitle>
            <i className="ri-calendar-check-line text-xl text-gray-400"></i>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedBookingsCount}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Successfully completed bookings
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <i className="ri-money-dollar-circle-line text-xl text-gray-400"></i>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalRevenue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              From all completed bookings
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Services</CardTitle>
            <i className="ri-service-line text-xl text-gray-400"></i>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{services?.length || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">
              <Link href="/admin/services" className="text-primary hover:underline">
                Manage services
              </Link>
            </p>
          </CardContent>
        </Card>
      </div>
      
      <h2 className="text-xl font-semibold mt-8 mb-4">Quick Stats</h2>
      
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {bookings?.slice(0, 5).map(booking => (
                <li key={booking.id} className="flex items-center justify-between">
                  <div>
                    <span className="text-sm font-medium">Booking #{booking.id}</span>
                    <p className="text-xs text-gray-500">
                      Client #{booking.clientId} booked Assistant #{booking.assistantId}
                    </p>
                  </div>
                  <span className="capitalize text-xs py-1 px-2 rounded bg-gray-100">
                    {booking.status}
                  </span>
                </li>
              ))}
              
              {(!bookings || bookings.length === 0) && (
                <li className="text-center py-3 text-gray-500">No recent bookings</li>
              )}
            </ul>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>System Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Server Status</span>
                <span className="text-green-500 font-medium">Online</span>
              </div>
              <div className="flex justify-between">
                <span>Database</span>
                <span className="text-green-500 font-medium">Connected</span>
              </div>
              <div className="flex justify-between">
                <span>API Health</span>
                <span className="text-green-500 font-medium">Good</span>
              </div>
              <div className="flex justify-between">
                <span>Last Updated</span>
                <span className="text-gray-500">Just now</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminPanel>
  );
};

export default AdminDashboard;
