import { FC } from 'react';
import { Link, useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import LoginForm from '@/components/auth/LoginForm';
import { useAuth } from '@/hooks/useAuth';

const Login: FC = () => {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  
  // If user is already logged in, redirect to home
  if (user) {
    setLocation('/');
    return null;
  }
  
  const handleLoginSuccess = () => {
    setLocation('/');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="mb-4 flex justify-center">
            <div className="h-20 w-20 rounded-full object-cover border-4 border-white shadow-lg bg-cover bg-center" 
                 style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1496372412473-e8548ffd82bc?auto=format&fit=crop&w=150&q=80)' }} />
          </div>
          <h1 className="font-poppins text-2xl font-bold text-gray-900 mb-1">My Personal Assistant</h1>
          <p className="text-gray-600">Costa Rica</p>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Sign In</CardTitle>
            <CardDescription>
              Enter your credentials to access your account
            </CardDescription>
          </CardHeader>
          <CardContent>
            <LoginForm onSuccess={handleLoginSuccess} />
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="text-center text-sm">
              Don't have an account?{' '}
              <Link href="/register" className="text-primary hover:underline">Sign Up</Link>
            </div>
            <div className="text-center">
              <Link href="/" className="text-sm text-gray-500 hover:text-gray-700 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m12 19-7-7 7-7"/>
                  <path d="M19 12H5"/>
                </svg>
                Back to home
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default Login;
